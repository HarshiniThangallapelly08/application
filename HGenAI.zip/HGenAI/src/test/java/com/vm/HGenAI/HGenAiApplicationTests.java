package com.vm.HGenAI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HGenAiApplicationTests {

	@Test
	void contextLoads() {
	}

}
