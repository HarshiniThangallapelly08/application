package com.vm.HGenAI;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HGenAiApplication {

	public static void main(String[] args) {
		SpringApplication.run(HGenAiApplication.class, args);
	}

}
